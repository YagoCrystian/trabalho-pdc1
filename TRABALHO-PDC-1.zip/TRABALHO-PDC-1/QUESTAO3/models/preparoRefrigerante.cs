using System;
using System.Threading.Tasks;

public class PreparoRefrigerante
{
    // Método para preparar refrigerante
    public Task<string> GetRefrigeranteAsync()
    {
        return Task.Run(() =>
        {
            Console.WriteLine("Iniciando o preparo do refrigerante...");
            Task.Delay(2000).Wait(); // Simula o tempo de preparo
            return "Refrigerante Pronto";
        });
    }
}
