using System;
using System.Threading.Tasks;

public class Pedido
{
    private PreparoPipoca preparoPipoca;
    private PreparoRefrigerante preparoRefrigerante;

    // Construtor
    public Pedido()
    {
        preparoPipoca = new PreparoPipoca();
        preparoRefrigerante = new PreparoRefrigerante();
    }

    // Método que retorna a string quando o lanche está pronto
    public async Task<string> LancheProntoAsync()
    {
        // Cria tarefas para pipoca e refrigerante
        var pipocaTask = preparoPipoca.GetPipocaAsync();
        var refrigeranteTask = preparoRefrigerante.GetRefrigeranteAsync();

        // Aguarda a conclusão de ambas as tarefas
        await Task.WhenAll(pipocaTask, refrigeranteTask);

        // Combina os resultados das tarefas e retorna a mensagem
        return $"Seu pedido está pronto! {pipocaTask.Result} e {refrigeranteTask.Result}";
    }

}
