using System;
using System.Threading.Tasks;

public class PreparoPipoca
{
    // Método para preparar pipoca
    public Task<string> GetPipocaAsync()
    {
        return Task.Run(() =>
        {
            Console.WriteLine("Iniciando o preparo da pipoca...");
            Task.Delay(3000).Wait(); // Simula o tempo de preparo
            return "Pipoca Pronta";
        });
    }
}
