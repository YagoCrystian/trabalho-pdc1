﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Cinema
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var pedido = new Pedido();

            Console.WriteLine("**************************************************");
            Console.WriteLine("        Bem-vindo ao Cinema do Shopping ABC       ");
            Console.WriteLine("**************************************************");
            Console.WriteLine();

            Console.WriteLine("Pedido realizado. Preparando pipoca e refrigerante...");
            Console.WriteLine();

            // Inicia o cronômetro
            var stopwatch = Stopwatch.StartNew();

            // Inicia o preparo do lanche e aguarda a conclusão
            var resultado = await pedido.LancheProntoAsync();

            // Para o cronômetro
            stopwatch.Stop();

            Console.WriteLine("**************************************************");
            Console.WriteLine("              Pedido Concluído com Sucesso        ");
            Console.WriteLine("**************************************************");
            Console.WriteLine();
            Console.WriteLine($"{resultado}");
            Console.WriteLine($"Tempo de execução: {stopwatch.ElapsedMilliseconds} ms");
            Console.WriteLine();
            Console.WriteLine("**************************************************");
            Console.WriteLine("       Obrigado por escolher nosso cinema!        ");
            Console.WriteLine("**************************************************");
        }
    }
}
