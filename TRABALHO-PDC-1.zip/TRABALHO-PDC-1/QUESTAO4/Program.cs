﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        int tamanhoVetor = 1000000;
        int numeroDeThreads = 4;

        VetorProcessor processor = new VetorProcessor(tamanhoVetor, numeroDeThreads);

        var startTime = DateTime.Now;
        int resultado = processor.CalcularSomaTotal();
        var endTime = DateTime.Now;

        Console.WriteLine($"Soma total: {resultado}");
        Console.WriteLine($"Tempo de execução: {(endTime - startTime).TotalMilliseconds} ms");
    }
}
