using System.Collections.Concurrent;

public class SomaThread
{
    private int[] vetor;
    private int inicio;
    private int fim;
    private ConcurrentBag<int> somaParcial;

    public SomaThread(int[] vetor, int inicio, int fim, ConcurrentBag<int> somaParcial)
    {
        this.vetor = vetor;
        this.inicio = inicio;
        this.fim = fim;
        this.somaParcial = somaParcial;
    }

    public void Run()
    {
        int somaLocal = 0;
        for (int i = inicio; i < fim; i++)
        {
            somaLocal += vetor[i];
        }
        somaParcial.Add(somaLocal);
    }
}
