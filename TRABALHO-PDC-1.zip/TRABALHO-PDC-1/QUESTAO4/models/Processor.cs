using System;
using System.Collections.Concurrent;
using System.Threading;

public class VetorProcessor
{
    private int[] vetor;
    private int numeroDeThreads;
    private ConcurrentBag<int> somaParcial;

    public VetorProcessor(int tamanhoVetor, int numeroDeThreads)
    {
        vetor = new int[tamanhoVetor];
        this.numeroDeThreads = numeroDeThreads;
        somaParcial = new ConcurrentBag<int>();
        PreencherVetor();
    }

    private void PreencherVetor()
    {
        Random rand = new Random();
        for (int i = 0; i < vetor.Length; i++)
        {
            vetor[i] = rand.Next(1, 100);
        }
    }

    public int CalcularSomaTotal()
    {
        int tamanhoDaParte = vetor.Length / numeroDeThreads;
        Thread[] threads = new Thread[numeroDeThreads];

        for (int i = 0; i < numeroDeThreads; i++)
        {
            int indiceInicio = i * tamanhoDaParte;
            int indiceFim = (i == numeroDeThreads - 1) ? vetor.Length : indiceInicio + tamanhoDaParte;

            SomaThread somaThread = new SomaThread(vetor, indiceInicio, indiceFim, somaParcial);
            threads[i] = new Thread(new ThreadStart(somaThread.Run));
            threads[i].Start();
        }

        foreach (Thread t in threads)
        {
            t.Join();
        }

        int somaTotal = 0;
        foreach (int soma in somaParcial)
        {
            somaTotal += soma;
        }

        return somaTotal;
    }
}
