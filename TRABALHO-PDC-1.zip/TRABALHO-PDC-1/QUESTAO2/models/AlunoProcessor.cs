using Universidade.Models;

namespace Universidade.Processors
{
    public class AlunoProcessor
    {
        public async Task<List<Aluno>> ProcessarArquivosAsync(string caminhoDiretorio)
        {
            var alunosConcluidos = new List<Aluno>();

            var arquivos = Directory.GetFiles(caminhoDiretorio, "*.txt");

            foreach (var arquivo in arquivos)
            {
                var linhas = await File.ReadAllLinesAsync(arquivo);

                foreach (var linha in linhas)
                {
                    var partes = linha.Split(' ');

                    // Verifica se a linha tem o formato esperado
                    if (partes.Length >= 4)
                    {
                        var aluno = new Aluno
                        {
                            Matricula = partes[0],
                            Nome = string.Join(' ', partes.Skip(1).Take(partes.Length - 3)),
                            Curso = partes[partes.Length - 2],
                            Flag = partes[partes.Length - 1]
                        };

                        if (aluno.Flag.Equals("CONCLUIDO", StringComparison.OrdinalIgnoreCase))
                        {
                            alunosConcluidos.Add(aluno);
                        }
                    }
                }
            }

            return alunosConcluidos;
        }
    }
}
