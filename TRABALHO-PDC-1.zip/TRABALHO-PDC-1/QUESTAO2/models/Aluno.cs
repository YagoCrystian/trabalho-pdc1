namespace Universidade.Models
{
    public class Aluno
    {
        public string? Matricula { get; set; }
        public string? Nome { get; set; }
        public string? Curso { get; set; }
        public string? Flag { get; set; }

        public override string ToString()
        {
            return $"{Matricula} {Nome} {Curso} {Flag}";
        }
    }
}
