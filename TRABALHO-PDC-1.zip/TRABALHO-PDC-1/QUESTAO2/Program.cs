﻿using System;
using System.Threading.Tasks;
using Universidade.Processors;

namespace Universidade
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var caminhoDiretorio = @"C:\Users\yago.teixeira\Desktop\TRABALHO-PDC-1\QUESTAO2\Data"; // Atualize com o caminho correto
            var processor = new AlunoProcessor();

            try
            {
                var alunosConcluidos = await processor.ProcessarArquivosAsync(caminhoDiretorio);

                Console.WriteLine("Alunos formandos encontrados:");
                foreach (var aluno in alunosConcluidos)
                {
                    Console.WriteLine(aluno);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
            }
        }
    }
}
