﻿using System;
using System.Threading;
using conta.models;
using conta.threads;

namespace conta
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Cria a conta bancária inicial com saldo de R$ 50
            ContaBancaria conta = new ContaBancaria(12345, "Titular Exemplo", 50);

            // Cria as instâncias das threads
            APatrocinadora patrocinadora = new APatrocinadora(conta);
            AGastadora gastadora = new AGastadora(conta);
            AEsperta esperta = new AEsperta(conta);
            AEconomica economica = new AEconomica(conta);

            // Cria e inicia as threads
            Thread tPatrocinadora = new Thread(new ThreadStart(patrocinadora.Run));
            Thread tGastadora = new Thread(new ThreadStart(gastadora.Run));
            Thread tEsperta = new Thread(new ThreadStart(esperta.Run));
            Thread tEconomica = new Thread(new ThreadStart(economica.Run));

            tPatrocinadora.Start();
            tGastadora.Start();
            tEsperta.Start();
            tEconomica.Start();

            // Espera um pouco para permitir que as threads executem
            Thread.Sleep(30000); // Ajuste o tempo conforme necessário

            // Interrompe as threads depois do tempo de execução
            tPatrocinadora.Interrupt();
            tGastadora.Interrupt();
            tEsperta.Interrupt();
            tEconomica.Interrupt();

            // Aguarda as threads terminarem
            tPatrocinadora.Join();
            tGastadora.Join();
            tEsperta.Join();
            tEconomica.Join();

            Console.WriteLine("Execução concluída.");
        }
    }
}
