using System;
using System.Threading;
using conta.models;

namespace conta.threads
{
    public class AGastadora
    {
        private readonly ContaBancaria conta;
        private int saquesRealizados;
        private decimal totalRetirado;

        public AGastadora(ContaBancaria conta)
        {
            this.conta = conta;
            saquesRealizados = 0;
            totalRetirado = 0;
        }

        public void Run()
        {
            while (true)
            {
                lock (conta)
                {
                    if (conta.Saldo == 0)
                    {
                        Console.WriteLine($"[AGastadora] Saldo zero. Saques realizados: {saquesRealizados}, Total retirado: {totalRetirado:C}. Aguardando...");
                        Monitor.Wait(conta);
                    }
                    else
                    {
                        if (conta.Sacar(10))
                        {
                            saquesRealizados++;
                            totalRetirado += 10;
                        }
                    }
                }
                Thread.Sleep(3000); // Espera 3000 ms
            }
        }
    }
}
