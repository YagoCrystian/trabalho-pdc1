using System;
using System.Threading;
using conta.models;

namespace conta.threads
{
    public class AEsperta
    {
        private readonly ContaBancaria conta;
        private int saquesRealizados;
        private decimal totalRetirado;

        public AEsperta(ContaBancaria conta)
        {
            this.conta = conta;
            saquesRealizados = 0;
            totalRetirado = 0;
        }

        public void Run()
        {
            while (true)
            {
                lock (conta)
                {
                    if (conta.Saldo == 0)
                    {
                        Console.WriteLine($"[AEsperta] Saldo zero. Saques realizados: {saquesRealizados}, Total retirado: {totalRetirado:C}. Aguardando...");
                        Monitor.Wait(conta); // Espera até que o saldo seja alterado
                    }
                    else
                    {
                        if (conta.Sacar(50)) // Chama o método Sacar com um argumento
                        {
                            saquesRealizados++;
                            totalRetirado += 50;
                        }
                    }
                }
                Thread.Sleep(6000); // Espera 6000 ms
            }
        }
    }
}
