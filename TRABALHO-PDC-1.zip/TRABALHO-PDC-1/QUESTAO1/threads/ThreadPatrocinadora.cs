using System;
using System.Threading;
using conta.models;

namespace conta.threads
{
    public class APatrocinadora
    {
        private readonly ContaBancaria conta;

        public APatrocinadora(ContaBancaria conta)
        {
            this.conta = conta;
        }

        public void Run()
        {
            while (true)
            {
                lock (conta)
                {
                    if (conta.Saldo == 0)
                    {
                        Console.WriteLine("[APatrocinadora] Saldo zerado. Depositando R$ 100.");
                        conta.Depositar(100);
                    }
                    else
                    {
                        // Se o saldo não estiver zerado, apenas aguarda um pouco antes de verificar novamente.
                        Monitor.Wait(conta);
                    }
                }
                Thread.Sleep(1000); // Espera 1000 ms antes de verificar novamente
            }
        }
    }
}
